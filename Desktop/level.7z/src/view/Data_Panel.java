package view;

import javax.swing.JPanel;

public class Data_Panel extends JPanel{

}
